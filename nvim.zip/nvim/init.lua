require("amir")
require("andromeda").setup()
