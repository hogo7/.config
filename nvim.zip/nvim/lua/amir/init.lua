require("amir.remap")
require("amir.set")

--print("hello from amir")
