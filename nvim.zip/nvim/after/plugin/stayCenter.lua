vim.keymap.set("n", "cen", function()
	require("stay-centered").setup()
end)
